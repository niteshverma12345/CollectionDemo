package CollectionDemo;
import java .util.ArrayList;
import java.util.List;
public class ArrayListDipendeny {
	void ArrayLIstExample() {
List<String> obj=new ArrayList();
obj.add("Nv");
obj.add("Shiva");
obj.add("nitin");
obj.add("amar");
for(String s:obj)
{
	System.out.println(s);
	}

}

}
