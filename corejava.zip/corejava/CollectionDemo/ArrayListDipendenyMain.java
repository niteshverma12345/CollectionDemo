package CollectionDemo;

public class ArrayListDipendenyMain {
	public static void main(String []args) {
		ArrayListDipendeny obj =new ArrayListDipendeny();{}
		obj.ArrayLIstExample();
	
	}}
