package CollectionDemo;
import java.util.ArrayList;
public class ArrayListExample {
	public static void main(String []args) {
		ArrayList obj=new ArrayList();
	obj.add('s');
	obj.add("23.34");
	obj.add(205.5f);
	obj.add("nitin");
	obj.add(1);
	for(int i=0;i<obj.size();i++)
	{
		System.out.println(obj.get(i));
	}
	}

}
