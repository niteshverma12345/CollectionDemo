package CollectionDemo;
import java .util.*;
import java.util.ArrayList;
public class ExampleArrayList {
	public static void main(String []args) {
		List<Integer> obj=new ArrayList<Integer>();
		obj.add(1);
		obj.add(2);
		obj.add(3);
		obj.add(4);
		obj.add(5);
		obj.add(6);
		obj.add(7);
		obj.add(8);
		obj.add(9);
		obj.add(10);
		Iterator<Integer>  it=obj.iterator();
while (it.hasNext());
Integer s=it.next();
System.out.println(s);

		}
		}
		  
		 
	


