package CollectionDemo;

public class GenricExample {
	private String name;
private	int id;
	  private int sall;
	GenricExample( String name,int id,int sall)	{
		this.name=name;
		this.id=id;
		this.sall=sall;
			}
 public	String toString(){
	return "name is"+"name"+"id is"+id+"sall is"+sall;	
	}

}
