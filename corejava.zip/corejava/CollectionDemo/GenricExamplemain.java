package CollectionDemo;

import java.util.ArrayList;

public class GenricExamplemain {
public static void main(String []args) {

	ArrayList<GenricExample>obj=new ArrayList<GenricExample>();
	obj.add( new GenricExample("NV",21,45));
	obj.add( new GenricExample("Nfg",24,454));
	obj.add( new GenricExample("Nn",263,44));
for(GenricExample s:obj) {
	System.out.println(s);
}

}
}
