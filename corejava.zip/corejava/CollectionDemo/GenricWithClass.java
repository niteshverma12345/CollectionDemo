package CollectionDemo;

public class GenricWithClass {
	private String name;
	private int idno,sall;

public GenricWithClass(String name, int idno, int sall) {
	super();
	this.name = name;
	this.idno = idno;
	this.sall = sall;
}
@Override
public String toString() {
	return "GenricWithClass [name=" + name + ", idno=" + idno + ", sall=" + sall + "]";
}




}
