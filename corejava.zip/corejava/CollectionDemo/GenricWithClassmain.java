package CollectionDemo;

import java.util.ArrayList;

public class GenricWithClassmain {
	
	public static void main(String []args) {
	
		
		ArrayList<GenricWithClass> obj1=new ArrayList<GenricWithClass>();
	    
		obj1.add(new GenricWithClass("ggdfhjh",5664,560));
		obj1.add(new GenricWithClass("ggdyryrf",5663,561));
		obj1.add(new GenricWithClass("ggdllf",5662,562));
		obj1.add(new GenricWithClass("gerrgdf",5661,563));
		
		for(Object o:obj1)
		{
			System.out.println(o);
		}

	}

}
