package CollectionDemo;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
class GetMaxNum {
	void GetMax() {
		List<Integer> obj=new ArrayList();
	obj.add(21);
	obj.add(42);
	obj.add(25);
	obj.add(56);
	obj.add(56);
	Iterator<Integer> it= obj.iterator();
	//Iterator<Integer> it =obj.iterator();
	while(it .hasNext());
	//while(it.hasNext());
	Integer a=it.next();
	System.out.println(a);	
	}

}
