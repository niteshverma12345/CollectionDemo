package CollectionDemo;
import java.util.LinkedList;

//import javax.swing.text.html.HTMLDocument.Iterator;
public class LinkListExample {
	public static void main(String []args) {
		LinkedList obj=new LinkedList();
		 obj.add(21);
		 obj.add("NV");
		 obj.add(24);
		 obj.add(35); 
		 obj.remove(2);
		 obj.addFirst(23);
		 obj.addLast(34);
	/*Iterator it= obj.terator();
	while(it.hasNext());
	obj a=it.next();
	{
		System.out.println(a);
	}*/
		 
		 for(int i=0;i<obj.size();i++)
			{
				System.out.println(obj.get(i));
			}
		 for(Object i:obj)
			//for(Object i=0;i<obj.size();i++) {
				System.out.println(i);
			}

		 }


