package CollectionDemo;

import java.util.ArrayList;
import java.util.Iterator;

public class genericDemo {
//void ArrayListDemo() {
	public static void main(String[]args) {
	ArrayList<Integer> obj= new ArrayList<Integer>();
	
obj.add(1);
obj.add(5);
obj.add(6);
obj.add(69);
obj.add(2);
Iterator<Integer> it =obj.iterator();
while(it.hasNext());
	{
Integer a=it.next();
	System.out.println(a);
	}}
	
}
